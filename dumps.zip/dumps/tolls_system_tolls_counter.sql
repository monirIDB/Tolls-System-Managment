CREATE DATABASE  IF NOT EXISTS `tolls_system` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `tolls_system`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win32 (AMD64)
--
-- Host: localhost    Database: tolls_system
-- ------------------------------------------------------
-- Server version	5.7.14-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tolls_counter`
--

DROP TABLE IF EXISTS `tolls_counter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tolls_counter` (
  `tollsId` int(11) NOT NULL AUTO_INCREMENT,
  `payment` bit(1) NOT NULL,
  `rate` double NOT NULL,
  `transportName` varchar(255) DEFAULT NULL,
  `vehicleDate` date DEFAULT NULL,
  `vehicleNo` varchar(255) DEFAULT NULL,
  `vehicleTime` time DEFAULT NULL,
  PRIMARY KEY (`tollsId`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tolls_counter`
--

LOCK TABLES `tolls_counter` WRITE;
/*!40000 ALTER TABLE `tolls_counter` DISABLE KEYS */;
INSERT INTO `tolls_counter` VALUES (1,'',500,'Car','2016-12-25','AZ-765','18:39:48'),(3,'',890,'Small Track',NULL,'A-Z794545',NULL),(5,'',1400,'Big Track','2016-12-27','A-F-4569','00:48:37'),(6,'',1100,'Medium Track','2016-12-31','AZ-43856','21:58:29'),(7,'',650,'Mini Bus','2017-01-01','AW-8956349','00:12:12'),(8,'',50,'Motorcycle','2017-01-01','AY-48759','00:25:01'),(9,'',1400,'Big Track','2017-01-01','YU-132466','00:56:01'),(10,'',650,'Mini Bus','2017-01-01','AZ-12345','01:10:37'),(11,'',1100,'Medium Track','2017-01-01','sdfdsfds','01:54:34'),(12,'',50,'Motorcycle','2017-01-01','dsfdsfds','01:55:08'),(13,'',50,'Motorcycle','2017-01-01','dfdfdf','01:55:35'),(14,'',1100,'Medium Track','2017-01-01','dfsdgfds','01:56:55'),(15,'',650,'Mini Bus','2017-01-01','rasddlfkd','02:15:15'),(16,'',500,'Car','2017-01-01','AZ-12345-56','08:51:07'),(17,'',650,'Mini Bus','2017-01-02','QW-35-9863','01:11:07'),(18,'',1400,'Big Track','2017-01-02','WQ-98-6597','01:12:16'),(19,'',650,'Mini Bus','2017-01-02','AZ-98-5896','23:47:32');
/*!40000 ALTER TABLE `tolls_counter` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-01-03 13:12:27
