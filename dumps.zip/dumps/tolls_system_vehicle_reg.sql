CREATE DATABASE  IF NOT EXISTS `tolls_system` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `tolls_system`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win32 (AMD64)
--
-- Host: localhost    Database: tolls_system
-- ------------------------------------------------------
-- Server version	5.7.14-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `vehicle_reg`
--

DROP TABLE IF EXISTS `vehicle_reg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehicle_reg` (
  `vehicleId` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `engineNo` varchar(255) DEFAULT NULL,
  `modelNo` varchar(255) DEFAULT NULL,
  `ownerName` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `vehicleName` varchar(255) DEFAULT NULL,
  `vehicleNo` varchar(255) DEFAULT NULL,
  `vehicleType` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`vehicleId`),
  UNIQUE KEY `UK_ri55lo4cphacylv7fog9wb1ua` (`engineNo`),
  UNIQUE KEY `UK_7orqehau6mwo3n04jos7jupyk` (`vehicleNo`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicle_reg`
--

LOCK TABLES `vehicle_reg` WRITE;
/*!40000 ALTER TABLE `vehicle_reg` DISABLE KEYS */;
INSERT INTO `vehicle_reg` VALUES (4,'Dhaka','0101654FJHFGJ','1223457','Rasel','+88-01815319013','Prodo','AZ-12-5836','Car'),(5,'Dhaka','DA5432SKDJFJ','QR2345','Sarwar','+88-01234567890','Frado','AT-12-9345','Car'),(6,'Dhaka','43sfsdhgf','489357rhg','Mizan','0123','Honda','12345678','Motorcycle'),(7,'Dhaka','093457HGFIR','MHDJ454','Hasan','+88-10213465688','Tata','AK-12-3454','Truck'),(8,'Dhaka','3578SJKFHDSKGS','FARARY','Rasel Ahmed','+88-01815319013','Toyota','AW-12-1234','Motorcycle'),(9,'Dhaka','DKJFGDSHK348975','MHDJ454','Sarwar','+88-12354510245','Volvo','AK-12-9546','Bus'),(12,'jgjgk','3578SJKFHDGHJ','MHDJ454','Rasel','+88-01815319013','Toyota','AK-12-1164','Motorcycle'),(13,'Dhaka','3578SJKKJHI','MHDJ454','Rasel','+88-01815319013','Toyota','AK-12-4556','Car'),(14,'Dhaka','ASGGD59DGFFD','DBO 1234','Rasel Ahmed','+88-01815319013','Honda','AZ-12-6585','Motorcycle');
/*!40000 ALTER TABLE `vehicle_reg` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-01-03 13:12:28
